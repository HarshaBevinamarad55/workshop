const mongoose =require("mongoose");

const productSchema =new mongoose.Schema({
    name:{
        type:String,
        required:true,
    },
    description:{
        type:String,
        required:true,
        minLength:10,
        maxLength:200,
    },
    category:{
        type:String,
        required:true,
    },
    price:{
        type:Number,
        required:true,
        min:100,
    },
    createdAt:{
        type:String,
        default:Date.now   
     },
});u

const product =mongoose.model("products", productSchema);

model.exports=products;